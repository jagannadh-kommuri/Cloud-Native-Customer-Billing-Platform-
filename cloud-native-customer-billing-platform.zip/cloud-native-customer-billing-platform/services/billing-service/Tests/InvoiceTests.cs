using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

public class InvoiceTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    public InvoiceTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.WithWebHostBuilder(b =>
        {
            b.UseSetting("USE_INMEMORY_DB", "true");
            b.UseSetting("MESSAGING_ENABLED", "false");
        }).CreateClient();
    }

    [Fact]
    public async Task CreateInvoice_IsIdempotentByPurchaseId()
    {
        long purchaseId = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var first = await _client.PostAsJsonAsync("/api/invoices", new { purchaseId, amount=99.98m, currency="USD" });
        first.EnsureSuccessStatusCode();
        var a = JsonDocument.Parse(await first.Content.ReadAsStringAsync()).RootElement;

        var second = await _client.PostAsJsonAsync("/api/invoices", new { purchaseId, amount=99.98m, currency="USD" });
        second.EnsureSuccessStatusCode();
        var b = JsonDocument.Parse(await second.Content.ReadAsStringAsync()).RootElement;
        Assert.Equal(a.GetProperty("id").GetInt64(), b.GetProperty("id").GetInt64());
    }
}
