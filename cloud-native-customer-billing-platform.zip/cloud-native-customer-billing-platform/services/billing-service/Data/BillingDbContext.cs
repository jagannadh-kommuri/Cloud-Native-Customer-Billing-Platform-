using BillingService.Models; using Microsoft.EntityFrameworkCore;
namespace BillingService.Data;
public class BillingDbContext(DbContextOptions<BillingDbContext> options):DbContext(options){ public DbSet<Invoice> Invoices=>Set<Invoice>(); protected override void OnModelCreating(ModelBuilder b){b.Entity<Invoice>().HasIndex(x=>x.PurchaseId).IsUnique();b.Entity<Invoice>().Property(x=>x.Amount).HasPrecision(18,2);} }
