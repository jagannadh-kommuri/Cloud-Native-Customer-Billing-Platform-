using BillingService.Data; using BillingService.Messaging; using BillingService.Models; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace BillingService.Controllers;
public record CreateInvoiceRequest(long PurchaseId, decimal Amount, string Currency="USD");
[ApiController,Route("api/invoices")]
public class InvoicesController(BillingDbContext db,IEventPublisher bus,IConfiguration cfg):ControllerBase
{
    [HttpPost] public async Task<IActionResult> Create(CreateInvoiceRequest req,CancellationToken ct){if(req.PurchaseId<=0||req.Amount<=0)return BadRequest(new{error="valid purchaseId and amount are required"}); var existing=await db.Invoices.AsNoTracking().FirstOrDefaultAsync(x=>x.PurchaseId==req.PurchaseId,ct); if(existing!=null)return Ok(existing); var inv=new Invoice{PurchaseId=req.PurchaseId,Amount=req.Amount,Currency=req.Currency};db.Add(inv);await db.SaveChangesAsync(ct); var evt=new{eventId=Guid.NewGuid(),eventType="billing.completed",occurredAt=DateTimeOffset.UtcNow,purchaseId=inv.PurchaseId,invoiceId=inv.Id,amount=inv.Amount,currency=inv.Currency,status=inv.Status};await bus.PublishAsync(cfg["BILLING_TOPIC"]??"billing-events",evt,ct);return Created($"/api/invoices/{inv.PurchaseId}",inv);} 
    [HttpGet("{purchaseId:long}")] public async Task<IActionResult> Get(long purchaseId,CancellationToken ct)=>await db.Invoices.AsNoTracking().FirstOrDefaultAsync(x=>x.PurchaseId==purchaseId,ct) is {} i?Ok(i):NotFound();
}
