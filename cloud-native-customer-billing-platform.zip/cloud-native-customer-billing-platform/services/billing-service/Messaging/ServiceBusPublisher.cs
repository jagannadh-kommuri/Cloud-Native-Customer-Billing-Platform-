using System.Collections.Concurrent;
using System.Text.Json;
using Azure.Messaging.ServiceBus;

namespace BillingService.Messaging;

public interface IEventPublisher { Task PublishAsync<T>(string topic, T payload, CancellationToken ct = default); }

public sealed class ServiceBusPublisher : IEventPublisher, IAsyncDisposable
{
    private readonly ILogger<ServiceBusPublisher> _log;
    private readonly ServiceBusClient? _client;
    private readonly ConcurrentDictionary<string, ServiceBusSender> _senders = new();

    public ServiceBusPublisher(IConfiguration cfg, ILogger<ServiceBusPublisher> log)
    {
        _log = log;
        if (cfg.GetValue<bool>("MESSAGING_ENABLED"))
        {
            var cs = cfg["AZURE_SERVICEBUS_CONNECTION_STRING"]
                     ?? throw new InvalidOperationException("Service Bus connection missing");
            _client = new ServiceBusClient(cs);
        }
    }

    public async Task PublishAsync<T>(string topic, T payload, CancellationToken ct = default)
    {
        if (_client is null)
        {
            _log.LogInformation("Messaging disabled; {Topic} not sent", topic);
            return;
        }
        var sender = _senders.GetOrAdd(topic, _client.CreateSender);
        await sender.SendMessageAsync(new ServiceBusMessage(JsonSerializer.Serialize(payload))
        {
            ContentType = "application/json",
            MessageId = Guid.NewGuid().ToString()
        }, ct);
    }

    public async ValueTask DisposeAsync()
    {
        foreach (var sender in _senders.Values) await sender.DisposeAsync();
        if (_client is not null) await _client.DisposeAsync();
    }
}
