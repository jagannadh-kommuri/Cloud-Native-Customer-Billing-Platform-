namespace BillingService.Models;
public class Invoice { public long Id {get;set;} public long PurchaseId {get;set;} public decimal Amount {get;set;} public string Currency {get;set;}="USD"; public string Status {get;set;}="Paid"; public DateTimeOffset CreatedAt {get;set;}=DateTimeOffset.UtcNow; }
