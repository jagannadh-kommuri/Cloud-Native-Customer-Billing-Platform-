using BillingService.Data; using BillingService.Messaging; using BillingService.Workers; using Microsoft.EntityFrameworkCore; using Prometheus;
var builder=WebApplication.CreateBuilder(args); builder.Services.AddControllers(); builder.Services.AddSwaggerGen(); builder.Services.AddHealthChecks();
var cs=builder.Configuration.GetConnectionString("BillingDb"); if(builder.Configuration.GetValue<bool>("USE_INMEMORY_DB") || string.IsNullOrWhiteSpace(cs)) builder.Services.AddDbContext<BillingDbContext>(o=>o.UseInMemoryDatabase("billing")); else builder.Services.AddDbContext<BillingDbContext>(o=>o.UseSqlServer(cs));
builder.Services.AddSingleton<IEventPublisher,ServiceBusPublisher>(); builder.Services.AddHostedService<PurchaseEventWorker>();
var app=builder.Build(); app.UseSwagger(); app.UseSwaggerUI(); app.UseHttpMetrics(); app.MapMetrics(); app.MapHealthChecks("/health"); app.MapControllers();
using(var scope=app.Services.CreateScope()){await scope.ServiceProvider.GetRequiredService<BillingDbContext>().Database.EnsureCreatedAsync();}
await app.RunAsync(); public partial class Program { }
