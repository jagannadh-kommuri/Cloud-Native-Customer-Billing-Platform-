namespace CommerceApi.Dtos;
public record CreateCustomerRequest(string Email, string Name);
public record CreateCatalogItemRequest(string Sku, string Name, decimal Price);
public record CreatePurchaseRequest(long CustomerId, long CatalogItemId, int Quantity);
