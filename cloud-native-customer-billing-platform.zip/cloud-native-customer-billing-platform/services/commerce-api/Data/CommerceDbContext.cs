using CommerceApi.Models;
using Microsoft.EntityFrameworkCore;
namespace CommerceApi.Data;
public class CommerceDbContext(DbContextOptions<CommerceDbContext> options) : DbContext(options)
{
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<CatalogItem> CatalogItems => Set<CatalogItem>();
    public DbSet<Purchase> Purchases => Set<Purchase>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Customer>().HasIndex(x => x.Email).IsUnique();
        b.Entity<CatalogItem>().HasIndex(x => x.Sku).IsUnique();
        b.Entity<Purchase>().HasIndex(x => x.IdempotencyKey).IsUnique();
        b.Entity<Purchase>().HasIndex(x => new { x.CustomerId, x.CreatedAt });
        b.Entity<CatalogItem>().Property(x => x.Price).HasPrecision(18,2);
        b.Entity<Purchase>().Property(x => x.Amount).HasPrecision(18,2);
    }
}
