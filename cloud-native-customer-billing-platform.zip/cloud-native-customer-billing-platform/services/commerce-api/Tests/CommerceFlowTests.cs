using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

public class CommerceFlowTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    public CommerceFlowTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.WithWebHostBuilder(b =>
        {
            b.UseSetting("USE_INMEMORY_DB", "true");
            b.UseSetting("MESSAGING_ENABLED", "false");
        }).CreateClient();
    }

    [Fact]
    public async Task CustomerCatalogPurchaseFlow_IsIdempotent()
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var customerResponse = await _client.PostAsJsonAsync("/api/customers", new { email=$"demo-{suffix}@example.com", name="Demo User" });
        customerResponse.EnsureSuccessStatusCode();
        var customer = JsonDocument.Parse(await customerResponse.Content.ReadAsStringAsync()).RootElement;
        long customerId = customer.GetProperty("id").GetInt64();

        var catalogResponse = await _client.PostAsJsonAsync("/api/catalog", new { sku=$"PRO-{suffix}", name="Pro Plan", price=49.99m });
        catalogResponse.EnsureSuccessStatusCode();
        var catalog = JsonDocument.Parse(await catalogResponse.Content.ReadAsStringAsync()).RootElement;
        long catalogItemId = catalog.GetProperty("id").GetInt64();

        using var first = new HttpRequestMessage(HttpMethod.Post, "/api/purchases");
        first.Headers.Add("Idempotency-Key", $"order-{suffix}");
        first.Content = JsonContent.Create(new { customerId, catalogItemId, quantity=2 });
        var firstResponse = await _client.SendAsync(first);
        firstResponse.EnsureSuccessStatusCode();
        var purchase = JsonDocument.Parse(await firstResponse.Content.ReadAsStringAsync()).RootElement;
        long purchaseId = purchase.GetProperty("id").GetInt64();

        using var second = new HttpRequestMessage(HttpMethod.Post, "/api/purchases");
        second.Headers.Add("Idempotency-Key", $"order-{suffix}");
        second.Content = JsonContent.Create(new { customerId, catalogItemId, quantity=2 });
        var secondResponse = await _client.SendAsync(second);
        secondResponse.EnsureSuccessStatusCode();
        var duplicate = JsonDocument.Parse(await secondResponse.Content.ReadAsStringAsync()).RootElement;
        Assert.Equal(purchaseId, duplicate.GetProperty("id").GetInt64());
    }
}
