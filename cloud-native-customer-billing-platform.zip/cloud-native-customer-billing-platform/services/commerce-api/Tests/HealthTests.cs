using Microsoft.AspNetCore.Hosting; using Microsoft.AspNetCore.Mvc.Testing; using Xunit;
public class HealthTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    public HealthTests(WebApplicationFactory<Program> factory) { _client=factory.WithWebHostBuilder(b=>b.UseSetting("USE_INMEMORY_DB","true")).CreateClient(); }
    [Fact] public async Task Health_ReturnsSuccess() { var r=await _client.GetAsync("/health"); r.EnsureSuccessStatusCode(); }
}
