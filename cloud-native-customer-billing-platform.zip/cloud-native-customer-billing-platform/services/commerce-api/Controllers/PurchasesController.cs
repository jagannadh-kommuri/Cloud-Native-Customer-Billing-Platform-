using CommerceApi.Data; using CommerceApi.Dtos; using CommerceApi.Messaging; using CommerceApi.Models; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace CommerceApi.Controllers;
[ApiController, Route("api/purchases")]
public class PurchasesController(CommerceDbContext db, IEventPublisher bus, IAuditStore audit, IConfiguration config) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Create(CreatePurchaseRequest req, CancellationToken ct)
    {
        var key=Request.Headers["Idempotency-Key"].FirstOrDefault();
        if(string.IsNullOrWhiteSpace(key)) return BadRequest(new{error="Idempotency-Key header is required"});
        var existing=await db.Purchases.AsNoTracking().FirstOrDefaultAsync(x=>x.IdempotencyKey==key,ct); if(existing!=null) return Ok(existing);
        if(req.Quantity<=0) return BadRequest(new{error="quantity must be positive"});
        var customer=await db.Customers.FindAsync(new object?[] { req.CustomerId },ct); var item=await db.CatalogItems.FindAsync(new object?[] { req.CatalogItemId },ct);
        if(customer is null || item is null || !item.Active) return BadRequest(new{error="valid customer and active catalog item are required"});
        var purchase=new Purchase{CustomerId=customer.Id,CatalogItemId=item.Id,Quantity=req.Quantity,Amount=item.Price*req.Quantity,IdempotencyKey=key};
        db.Purchases.Add(purchase); await db.SaveChangesAsync(ct);
        var evt=new { id=Guid.NewGuid().ToString(), partitionKey=$"purchase-{purchase.Id}", eventId=Guid.NewGuid(), eventType="purchase.created", occurredAt=DateTimeOffset.UtcNow, purchaseId=purchase.Id, customerId=customer.Id, sku=item.Sku, quantity=purchase.Quantity, amount=purchase.Amount, currency=purchase.Currency };
        await bus.PublishAsync(config["PURCHASE_TOPIC"] ?? "purchase-events",evt,ct); await audit.WriteAsync(evt,$"purchase-{purchase.Id}",ct);
        return Created($"/api/purchases/{purchase.Id}",purchase);
    }
    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id,CancellationToken ct) => await db.Purchases.AsNoTracking().FirstOrDefaultAsync(x=>x.Id==id,ct) is { } p ? Ok(p) : NotFound();
}
