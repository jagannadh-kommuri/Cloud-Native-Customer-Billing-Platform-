using CommerceApi.Data; using CommerceApi.Dtos; using CommerceApi.Models; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace CommerceApi.Controllers;
[ApiController, Route("api/catalog")]
public class CatalogController(CommerceDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery]int page=1,[FromQuery]int pageSize=50,CancellationToken ct=default)
    { page=Math.Max(1,page); pageSize=Math.Clamp(pageSize,1,100); var items=await db.CatalogItems.AsNoTracking().Where(x=>x.Active).OrderBy(x=>x.Id).Skip((page-1)*pageSize).Take(pageSize).ToListAsync(ct); return Ok(items); }
    [HttpPost]
    public async Task<IActionResult> Create(CreateCatalogItemRequest req,CancellationToken ct)
    { if(req.Price<=0 || string.IsNullOrWhiteSpace(req.Sku)) return BadRequest(new{error="valid sku and positive price are required"}); var item=new CatalogItem{Sku=req.Sku.Trim().ToUpperInvariant(),Name=req.Name.Trim(),Price=req.Price}; db.Add(item); await db.SaveChangesAsync(ct); return Created($"/api/catalog/{item.Id}",item); }
}
