using CommerceApi.Data; using CommerceApi.Dtos; using CommerceApi.Models; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace CommerceApi.Controllers;
[ApiController, Route("api/customers")]
public class CustomersController(CommerceDbContext db) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Create(CreateCustomerRequest req, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(req.Email) || string.IsNullOrWhiteSpace(req.Name)) return BadRequest(new { error="name and email are required" });
        if (await db.Customers.AnyAsync(x=>x.Email==req.Email, ct)) return Conflict(new { error="email already exists" });
        var customer=new Customer { Email=req.Email.Trim().ToLowerInvariant(), Name=req.Name.Trim() };
        db.Customers.Add(customer); await db.SaveChangesAsync(ct); return CreatedAtAction(nameof(Get), new { id=customer.Id }, customer);
    }
    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id, CancellationToken ct) => await db.Customers.FindAsync(new object?[] { id }, ct) is { } c ? Ok(c) : NotFound();
}
