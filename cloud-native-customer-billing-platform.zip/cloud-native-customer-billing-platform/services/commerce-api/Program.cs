using CommerceApi.Data;
using CommerceApi.Messaging;
using Microsoft.EntityFrameworkCore;
using Prometheus;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHealthChecks();

var cs = builder.Configuration.GetConnectionString("CommerceDb");
if (builder.Configuration.GetValue<bool>("USE_INMEMORY_DB") || string.IsNullOrWhiteSpace(cs))
    builder.Services.AddDbContext<CommerceDbContext>(o => o.UseInMemoryDatabase("commerce"));
else
    builder.Services.AddDbContext<CommerceDbContext>(o => o.UseSqlServer(cs));

builder.Services.AddSingleton<IEventPublisher, ServiceBusEventPublisher>();
builder.Services.AddSingleton<IAuditStore, CosmosAuditStore>();

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpMetrics();
app.MapMetrics();
app.MapHealthChecks("/health");
app.MapControllers();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<CommerceDbContext>();
    await db.Database.EnsureCreatedAsync();
}

await app.RunAsync();
public partial class Program { }
