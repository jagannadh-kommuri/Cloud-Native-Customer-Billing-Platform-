using System.Collections.Concurrent;
using System.Text.Json;
using Azure.Messaging.ServiceBus;

namespace CommerceApi.Messaging;

public sealed class ServiceBusEventPublisher : IEventPublisher, IAsyncDisposable
{
    private readonly IConfiguration _config;
    private readonly ILogger<ServiceBusEventPublisher> _log;
    private readonly ServiceBusClient? _client;
    private readonly ConcurrentDictionary<string, ServiceBusSender> _senders = new();

    public ServiceBusEventPublisher(IConfiguration config, ILogger<ServiceBusEventPublisher> log)
    {
        _config = config;
        _log = log;
        if (_config.GetValue<bool>("MESSAGING_ENABLED"))
        {
            var cs = _config["AZURE_SERVICEBUS_CONNECTION_STRING"]
                     ?? throw new InvalidOperationException("AZURE_SERVICEBUS_CONNECTION_STRING is required when messaging is enabled");
            _client = new ServiceBusClient(cs);
        }
    }

    public async Task PublishAsync<T>(string topic, T payload, CancellationToken ct = default)
    {
        if (_client is null)
        {
            _log.LogInformation("Messaging disabled; event {Topic} not sent", topic);
            return;
        }

        var sender = _senders.GetOrAdd(topic, _client.CreateSender);
        var json = JsonSerializer.Serialize(payload);
        var message = new ServiceBusMessage(json)
        {
            ContentType = "application/json",
            MessageId = Guid.NewGuid().ToString()
        };
        await sender.SendMessageAsync(message, ct);
    }

    public async ValueTask DisposeAsync()
    {
        foreach (var sender in _senders.Values) await sender.DisposeAsync();
        if (_client is not null) await _client.DisposeAsync();
    }
}
