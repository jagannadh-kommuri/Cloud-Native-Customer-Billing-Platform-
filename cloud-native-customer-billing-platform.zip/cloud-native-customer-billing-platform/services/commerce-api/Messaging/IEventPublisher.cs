namespace CommerceApi.Messaging;
public interface IEventPublisher { Task PublishAsync<T>(string topic, T payload, CancellationToken ct = default); }
