using Microsoft.Azure.Cosmos;
namespace CommerceApi.Messaging;
public interface IAuditStore { Task WriteAsync(object document, string partitionKey, CancellationToken ct = default); }
public sealed class CosmosAuditStore(IConfiguration config, ILogger<CosmosAuditStore> log) : IAuditStore
{
    public async Task WriteAsync(object document, string partitionKey, CancellationToken ct = default)
    {
        var endpoint=config["COSMOS_ENDPOINT"]; var key=config["COSMOS_KEY"];
        if (string.IsNullOrWhiteSpace(endpoint) || string.IsNullOrWhiteSpace(key)) { log.LogDebug("Cosmos audit disabled"); return; }
        using var client = new CosmosClient(endpoint, key);
        var db = await client.CreateDatabaseIfNotExistsAsync(config["COSMOS_DATABASE"] ?? "commerce-platform", cancellationToken: ct);
        var container = await db.Database.CreateContainerIfNotExistsAsync(config["COSMOS_CONTAINER"] ?? "audit-events", "/partitionKey", cancellationToken: ct);
        await container.Container.CreateItemAsync(document, new PartitionKey(partitionKey), cancellationToken: ct);
    }
}
