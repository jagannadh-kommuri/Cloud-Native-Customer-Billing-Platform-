namespace CommerceApi.Models;
public class CatalogItem { public long Id { get; set; } public required string Sku { get; set; } public required string Name { get; set; } public decimal Price { get; set; } public bool Active { get; set; } = true; }
