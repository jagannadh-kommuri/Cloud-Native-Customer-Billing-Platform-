namespace CommerceApi.Models;
public class Customer { public long Id { get; set; } public required string Email { get; set; } public required string Name { get; set; } public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow; }
