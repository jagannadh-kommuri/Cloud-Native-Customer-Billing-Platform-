package com.example.fulfillment; import com.example.fulfillment.service.FulfillmentStore; import org.junit.jupiter.api.Test; import static org.junit.jupiter.api.Assertions.*;
class FulfillmentStoreTest { @Test void createIsIdempotent(){var s=new FulfillmentStore();var a=s.create(10,20);var b=s.create(10,99);assertEquals(a,b);assertEquals(20,a.invoiceId());} }
