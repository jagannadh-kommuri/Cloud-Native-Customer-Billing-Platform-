package com.example.fulfillment.messaging;

import com.azure.messaging.servicebus.*;
import com.example.fulfillment.service.CosmosAuditService;
import com.example.fulfillment.service.FulfillmentStore;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class BillingEventConsumer {
    private static final Logger log = LoggerFactory.getLogger(BillingEventConsumer.class);
    private final FulfillmentStore store;
    private final CosmosAuditService audit;
    private final ObjectMapper mapper = new ObjectMapper();
    private ServiceBusProcessorClient processor;

    @Value("${messaging.enabled:false}") boolean enabled;
    @Value("${messaging.connection-string:}") String connection;
    @Value("${messaging.billing-topic:billing-events}") String topic;
    @Value("${messaging.billing-subscription:fulfillment-service}") String subscription;

    public BillingEventConsumer(FulfillmentStore store, CosmosAuditService audit) {
        this.store = store;
        this.audit = audit;
    }

    @PostConstruct
    public void start() {
        if (!enabled) { log.info("Billing event consumer disabled"); return; }
        if (connection.isBlank()) throw new IllegalStateException("Service Bus connection missing");
        processor = new ServiceBusClientBuilder().connectionString(connection).processor()
                .topicName(topic).subscriptionName(subscription)
                .processMessage(this::handle)
                .processError(e -> log.error("Service Bus error", e.getException()))
                .buildProcessorClient();
        processor.start();
    }

    private void handle(ServiceBusReceivedMessageContext ctx) {
        try {
            JsonNode n = mapper.readTree(ctx.getMessage().getBody().toString());
            long purchaseId = n.get("purchaseId").asLong();
            long invoiceId = n.get("invoiceId").asLong();
            var fulfillment = store.create(purchaseId, invoiceId);
            audit.recordFulfillment(purchaseId, invoiceId, fulfillment.status());
            ctx.complete();
        } catch (Exception e) {
            log.error("Failed billing event", e);
            ctx.abandon();
        }
    }

    @PreDestroy
    public void stop() { if (processor != null) processor.close(); }
}
