package com.example.fulfillment.model;
import java.time.OffsetDateTime;
public record Fulfillment(long purchaseId,long invoiceId,String status,OffsetDateTime createdAt) {}
