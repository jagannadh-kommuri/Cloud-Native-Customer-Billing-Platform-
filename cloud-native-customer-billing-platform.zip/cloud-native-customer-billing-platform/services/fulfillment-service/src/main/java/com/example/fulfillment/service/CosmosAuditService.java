package com.example.fulfillment.service;

import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.CosmosContainer;
import com.azure.cosmos.models.CosmosItemRequestOptions;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class CosmosAuditService {
    private static final Logger log = LoggerFactory.getLogger(CosmosAuditService.class);
    @Value("${cosmos.endpoint:}") String endpoint;
    @Value("${cosmos.key:}") String key;
    @Value("${cosmos.database:commerce-platform}") String database;
    @Value("${cosmos.container:audit-events}") String containerName;
    private CosmosClient client;
    private CosmosContainer container;

    @PostConstruct
    void init() {
        if (endpoint.isBlank() || key.isBlank()) {
            log.info("Cosmos audit disabled");
            return;
        }
        client = new CosmosClientBuilder().endpoint(endpoint).key(key).buildClient();
        client.createDatabaseIfNotExists(database);
        var db = client.getDatabase(database);
        db.createContainerIfNotExists(containerName, "/partitionKey");
        container = db.getContainer(containerName);
    }

    public void recordFulfillment(long purchaseId, long invoiceId, String status) {
        if (container == null) return;
        Map<String, Object> doc = new LinkedHashMap<>();
        doc.put("id", UUID.randomUUID().toString());
        doc.put("partitionKey", "purchase-" + purchaseId);
        doc.put("eventType", "fulfillment.created");
        doc.put("purchaseId", purchaseId);
        doc.put("invoiceId", invoiceId);
        doc.put("status", status);
        doc.put("occurredAt", OffsetDateTime.now().toString());
        container.createItem(doc, new com.azure.cosmos.models.PartitionKey("purchase-" + purchaseId), new CosmosItemRequestOptions());
    }

    @PreDestroy
    void close() { if (client != null) client.close(); }
}
