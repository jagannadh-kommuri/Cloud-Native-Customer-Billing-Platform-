# Project Description — Cloud-Native Customer & Billing Platform

## Short GitHub description

Event-driven customer, catalog, billing, and fulfillment platform built with C#, Java, Azure Service Bus, Azure SQL, Cosmos DB, Docker, Kubernetes/AKS, Terraform, monitoring, and CI/CD.

## Recruiter-friendly summary

Cloud-Native Customer & Billing Platform is a microservices project that models customer accounts, product catalog, purchase, billing, and fulfillment workflows. The system uses C#/.NET and Java/Spring Boot services with REST APIs, Azure Service Bus event processing, a Service Bus-triggered Azure Function, Azure SQL transactional storage, Cosmos DB audit history, Docker containers, AKS deployment manifests, observability endpoints, automated tests, and GitHub Actions CI.

## Resume bullets

Use only metrics you can reproduce or explain:

- Developed C# and Java microservices and REST APIs for customer accounts, transactions, catalog, purchase, fulfillment, and billing workflows using Azure and event-driven architecture.
- Built asynchronous services using Azure Functions/Service Bus patterns, Azure SQL, Cosmos DB, Docker, AKS, monitoring, automated testing, and CI/CD pipelines.
- Optimized indexed SQL query paths, async processing, and service-level request handling; use `scripts/benchmark.py` to measure and document the resulting performance improvement before adding a percentage to your resume.

## Interview explanation

The project is split into three services. The Commerce API owns customer, catalog, and purchase data. A purchase publishes a `purchase.created` event. The Billing service consumes that event idempotently, creates an invoice, and publishes `billing.completed`. The Java Fulfillment service consumes the billing event and creates a fulfillment record. Azure SQL is used for transactional data, Cosmos DB is used for audit/event history, and the services expose health and metrics endpoints for reliability monitoring.

The architecture demonstrates REST API design, distributed ownership, eventual consistency, asynchronous messaging, idempotency, data indexing, containerization, CI/CD, and Kubernetes deployment patterns.
