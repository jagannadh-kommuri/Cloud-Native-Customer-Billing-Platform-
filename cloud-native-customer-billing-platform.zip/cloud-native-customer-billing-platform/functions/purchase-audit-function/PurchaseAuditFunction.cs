using System.Text.Json;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace PurchaseAuditFunction;

public class PurchaseAudit(ILogger<PurchaseAudit> logger)
{
    [Function("PurchaseAudit")]
    public async Task Run(
        [ServiceBusTrigger("purchase-events", "purchase-audit-function", Connection = "ServiceBusConnection")] string message)
    {
        using var doc = JsonDocument.Parse(message);
        var root = doc.RootElement;
        var purchaseId = root.GetProperty("purchaseId").GetInt64();
        logger.LogInformation("Auditing purchase event for purchase {PurchaseId}", purchaseId);

        var endpoint = Environment.GetEnvironmentVariable("CosmosEndpoint");
        var key = Environment.GetEnvironmentVariable("CosmosKey");
        if (string.IsNullOrWhiteSpace(endpoint) || string.IsNullOrWhiteSpace(key))
        {
            logger.LogWarning("Cosmos configuration is missing; event was validated but not persisted");
            return;
        }

        using var client = new CosmosClient(endpoint, key);
        var database = await client.CreateDatabaseIfNotExistsAsync(
            Environment.GetEnvironmentVariable("CosmosDatabase") ?? "commerce-platform");
        var container = await database.Database.CreateContainerIfNotExistsAsync(
            Environment.GetEnvironmentVariable("CosmosContainer") ?? "audit-events", "/partitionKey");

        var audit = new
        {
            id = Guid.NewGuid().ToString(),
            partitionKey = $"purchase-{purchaseId}",
            eventType = "purchase.audit",
            purchaseId,
            sourceEvent = JsonSerializer.Deserialize<object>(message),
            auditedAt = DateTimeOffset.UtcNow
        };
        await container.Container.CreateItemAsync(audit, new PartitionKey(audit.partitionKey));
    }
}
