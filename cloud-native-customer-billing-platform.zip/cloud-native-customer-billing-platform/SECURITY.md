# Security

This repository contains no production credentials.

For real deployments:

- store application secrets in Azure Key Vault;
- prefer workload identity / managed identity over long-lived secrets;
- use private endpoints for Azure SQL, Service Bus, Cosmos DB, and ACR where appropriate;
- use least-privilege database identities;
- enforce TLS and authentication at the ingress/API gateway layer;
- validate all request DTOs and message schemas;
- enable Service Bus dead-letter monitoring;
- enable Microsoft Defender / container image scanning for ACR;
- rotate credentials and never commit `.env`, Terraform state, or Kubernetes Secret values.

The Kubernetes Secret manifest contains placeholder strings only. Replace it with Key Vault CSI or External Secrets for production.
