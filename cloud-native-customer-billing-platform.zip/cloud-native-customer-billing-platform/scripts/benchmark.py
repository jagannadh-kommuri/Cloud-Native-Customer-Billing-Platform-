#!/usr/bin/env python3
"""Small latency harness for the Commerce catalog endpoint.

Example:
    python scripts/benchmark.py --url http://localhost:8080/api/catalog --requests 200
"""
import argparse, statistics, time, urllib.request

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--url', default='http://localhost:8080/api/catalog')
    p.add_argument('--requests', type=int, default=100)
    args=p.parse_args()
    samples=[]
    ok=0
    for _ in range(args.requests):
        start=time.perf_counter()
        try:
            with urllib.request.urlopen(args.url, timeout=10) as r:
                r.read()
                ok += int(200 <= r.status < 300)
        finally:
            samples.append((time.perf_counter()-start)*1000)
    samples_sorted=sorted(samples)
    p95=samples_sorted[max(0, int(len(samples_sorted)*0.95)-1)]
    print(f'requests={len(samples)} success={ok}')
    print(f'avg_ms={statistics.mean(samples):.2f} median_ms={statistics.median(samples):.2f} p95_ms={p95:.2f}')

if __name__=='__main__': main()
