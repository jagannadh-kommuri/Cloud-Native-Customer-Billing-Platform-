# GitHub Setup

1. Create a new GitHub repository named `cloud-native-customer-billing-platform`.
2. Do not initialize it with a README, `.gitignore`, or license; this project already contains them.
3. Open a terminal in the extracted project folder.
4. Run:

```bash
git init
git add .
git commit -m "Initial commit - cloud native customer billing platform"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/cloud-native-customer-billing-platform.git
git push -u origin main
```

Before pushing, confirm that `.env`, Terraform state, and real credentials are not staged:

```bash
git status
git diff --cached
```
