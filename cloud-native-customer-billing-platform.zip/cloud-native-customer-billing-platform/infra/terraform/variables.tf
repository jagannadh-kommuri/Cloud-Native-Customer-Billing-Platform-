variable "location" { type=string default="centralus" }
variable "prefix" { type=string default="jkbilling" }
variable "sql_admin_login" { type=string default="sqladminuser" }
variable "sql_admin_password" { type=string sensitive=true }
