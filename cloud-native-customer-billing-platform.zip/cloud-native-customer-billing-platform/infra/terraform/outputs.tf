output "resource_group" { value=azurerm_resource_group.rg.name }
output "acr_login_server" { value=azurerm_container_registry.acr.login_server }
output "aks_name" { value=azurerm_kubernetes_cluster.aks.name }
output "servicebus_namespace" { value=azurerm_servicebus_namespace.sb.name }
output "cosmos_endpoint" { value=azurerm_cosmosdb_account.cosmos.endpoint }
output "sql_server_fqdn" { value=azurerm_mssql_server.sql.fully_qualified_domain_name }
