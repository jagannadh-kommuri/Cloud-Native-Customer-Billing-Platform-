resource "random_string" "suffix" { length=6 special=false upper=false }
locals { name="${var.prefix}${random_string.suffix.result}" }
resource "azurerm_resource_group" "rg" { name="${local.name}-rg" location=var.location }
resource "azurerm_log_analytics_workspace" "law" { name="${local.name}-law" location=var.location resource_group_name=azurerm_resource_group.rg.name sku="PerGB2018" retention_in_days=30 }
resource "azurerm_application_insights" "ai" { name="${local.name}-appi" location=var.location resource_group_name=azurerm_resource_group.rg.name workspace_id=azurerm_log_analytics_workspace.law.id application_type="web" }
resource "azurerm_container_registry" "acr" { name=replace(local.name,"-","") resource_group_name=azurerm_resource_group.rg.name location=var.location sku="Basic" admin_enabled=false }
resource "azurerm_kubernetes_cluster" "aks" { name="${local.name}-aks" location=var.location resource_group_name=azurerm_resource_group.rg.name dns_prefix="${local.name}-aks" default_node_pool { name="system" node_count=2 vm_size="Standard_D2s_v5" } identity { type="SystemAssigned" } oms_agent { log_analytics_workspace_id=azurerm_log_analytics_workspace.law.id } }
resource "azurerm_role_assignment" "acr_pull" { scope=azurerm_container_registry.acr.id role_definition_name="AcrPull" principal_id=azurerm_kubernetes_cluster.aks.kubelet_identity[0].object_id }
resource "azurerm_servicebus_namespace" "sb" { name="${local.name}-sb" location=var.location resource_group_name=azurerm_resource_group.rg.name sku="Standard" }
resource "azurerm_servicebus_topic" "purchase" { name="purchase-events" namespace_id=azurerm_servicebus_namespace.sb.id }
resource "azurerm_servicebus_subscription" "billing" { name="billing-service" topic_id=azurerm_servicebus_topic.purchase.id max_delivery_count=10 }
resource "azurerm_servicebus_topic" "billing_topic" { name="billing-events" namespace_id=azurerm_servicebus_namespace.sb.id }
resource "azurerm_servicebus_subscription" "fulfillment" { name="fulfillment-service" topic_id=azurerm_servicebus_topic.billing_topic.id max_delivery_count=10 }
resource "azurerm_cosmosdb_account" "cosmos" { name="${local.name}-cosmos" location=var.location resource_group_name=azurerm_resource_group.rg.name offer_type="Standard" kind="GlobalDocumentDB" consistency_policy { consistency_level="Session" } geo_location { location=var.location failover_priority=0 } }
resource "azurerm_cosmosdb_sql_database" "db" { name="commerce-platform" resource_group_name=azurerm_resource_group.rg.name account_name=azurerm_cosmosdb_account.cosmos.name }
resource "azurerm_cosmosdb_sql_container" "audit" { name="audit-events" resource_group_name=azurerm_resource_group.rg.name account_name=azurerm_cosmosdb_account.cosmos.name database_name=azurerm_cosmosdb_sql_database.db.name partition_key_paths=["/partitionKey"] }
resource "azurerm_mssql_server" "sql" { name="${local.name}-sql" resource_group_name=azurerm_resource_group.rg.name location=var.location version="12.0" administrator_login=var.sql_admin_login administrator_login_password=var.sql_admin_password minimum_tls_version="1.2" }
resource "azurerm_mssql_database" "commerce" { name="CommerceDb" server_id=azurerm_mssql_server.sql.id sku_name="S0" }
resource "azurerm_mssql_database" "billing" { name="BillingDb" server_id=azurerm_mssql_server.sql.id sku_name="S0" }
resource "azurerm_servicebus_subscription" "purchase_audit" { name="purchase-audit-function" topic_id=azurerm_servicebus_topic.purchase.id max_delivery_count=10 }
