# Architecture

## Service boundaries

### Commerce API
Owns customers, catalog items, and purchases. Uses Azure SQL. Emits `purchase.created`.

### Billing Service
Owns invoices. Consumes `purchase.created`, creates invoices idempotently, and emits `billing.completed`.

### Fulfillment Service
Owns fulfillment state. Consumes `billing.completed` and stores fulfillment/audit information.

## Event contracts

### purchase.created

```json
{
  "eventId": "uuid",
  "eventType": "purchase.created",
  "occurredAt": "2026-09-16T12:00:00Z",
  "purchaseId": 1001,
  "customerId": 42,
  "sku": "PRO-001",
  "quantity": 2,
  "amount": 99.98,
  "currency": "USD"
}
```

### billing.completed

```json
{
  "eventId": "uuid",
  "eventType": "billing.completed",
  "occurredAt": "2026-09-16T12:00:02Z",
  "purchaseId": 1001,
  "invoiceId": 501,
  "amount": 99.98,
  "currency": "USD",
  "status": "Paid"
}
```

## Reliability decisions

- Every message carries an immutable event ID.
- Billing has a unique index on purchase ID to make event handling idempotent.
- Purchase creation accepts an `Idempotency-Key` header.
- Consumers complete a message only after durable processing succeeds.
- Failed Service Bus messages are abandoned so normal retry/dead-letter behavior can apply.
- Readiness/liveness endpoints allow AKS to remove unhealthy pods.
- HPA targets CPU utilization and services define CPU/memory requests and limits.

## Data choices

Azure SQL is appropriate for customers, catalog, purchases, and invoices because the workflows require relational consistency and indexed lookup paths. Cosmos DB is used for append-style audit/event records where flexible JSON documents and partitioned access are useful.
